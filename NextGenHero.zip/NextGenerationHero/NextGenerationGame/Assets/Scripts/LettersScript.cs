using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LettersScript : MonoBehaviour
{
    private GameController mGameGameController = null;
    public float letterHealth = 100f;
    // Start is called before the first frame update
    void Start()
    {
        mGameGameController = FindObjectOfType <GameController>();
        //gameObject.tag = "Letter";
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void UpdateColor(float amount)
    {
        float decreaseAmount = amount / 100f;
        SpriteRenderer s = GetComponent<SpriteRenderer>();
        
        Color c = s.color;
        float delta = decreaseAmount;
        c.r -= delta;
        c.a -= delta;
        s.color = c;
        Debug.Log("Letter: Color = " + c);

        if (c.a <= 0.0f)
        {
            Sprite t = Resources.Load<Sprite>("Textures/Egg");   // File name with respect to "Resources/" folder
            s.sprite = t;
            s.color = Color.white;
        }
    }
    
     public void TakeDamage(float amount)
     {
         
         letterHealth -= amount;
         Debug.Log("Letter Health: " + letterHealth);
         
         if (letterHealth <= 0)
         {
             Die();
         }
         else
         {
            UpdateColor(amount);
         }
     }
     void Die()
     {
         mGameGameController.LetterDestroyed(gameObject.tag);
         Destroy(gameObject);
     }
}
