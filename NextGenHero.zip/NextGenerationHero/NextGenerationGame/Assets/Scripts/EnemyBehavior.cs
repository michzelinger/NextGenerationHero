using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehavior : MonoBehaviour
{
    public Transform[] waypoints;
    Transform targetWayPoint;
   // private gameObject targetWayPoint;
    //waypoints.Length = 6;
    int current = 0;
    public float speed;
    //private float WPradius = 0.2f;
    private GameController mGameGameController = null;
    public float enemyHealth = 100f;
    // Start is called before the first frame update
    void Start()
    {
        //waypoints = new GameObject[waypointsSize];
        mGameGameController = FindObjectOfType <GameController>();
        gameObject.tag = "Enemy";
    }

    // Update is called once per frame
    void Update()
    {
        if(current < this.waypoints.Length)
         {
             if(targetWayPoint == null)
                 targetWayPoint = waypoints[current];
             walk();
         }
        
    }
    void walk(){
         // rotate towards the target
         Vector3 vectorToTarget = targetWayPoint.position - transform.position;
         float angle = Mathf.Atan2(vectorToTarget.y, vectorToTarget.x) * Mathf.Rad2Deg;
         Quaternion q = Quaternion.AngleAxis(angle, Vector3.forward);
         transform.rotation = Quaternion.Slerp(transform.rotation, q, Time.deltaTime * speed);
         //transform.forward = Vector3.RotateTowards(transform.forward, targetWayPoint.position - transform.position, speed*Time.smoothDeltaTime, 0.0f);
 
         // move towards the target
         transform.position = Vector3.MoveTowards(transform.position, targetWayPoint.position,   speed*Time.deltaTime);
 
         if(transform.position == targetWayPoint.position)
         {
             current++ ;
             targetWayPoint = waypoints[current];
         }
     } 
    private void UpdateColor(float amount)
    {
        float decreaseAmount = amount / 100f;
        SpriteRenderer s = GetComponent<SpriteRenderer>();
        
        Color c = s.color;
        float delta = decreaseAmount;
        c.r -= delta;
        c.a -= delta;
        s.color = c;
        Debug.Log("Plane: Color = " + c);

        if (c.a <= 0.0f)
        {
            Sprite t = Resources.Load<Sprite>("Textures/Egg");   // File name with respect to "Resources/" folder
            s.sprite = t;
            s.color = Color.white;
        }
    }
    
     public void TakeDamage(float amount)
     {
         
         enemyHealth -= amount;
         Debug.Log("Enemy Health: " + enemyHealth);
         
         if (enemyHealth <= 0)
         {
             Die();
         }
         else
         {
            UpdateColor(amount);
         }
     }
     void Die()
     {
         Destroy(gameObject);
         mGameGameController.EnemyDestroyed();
     }
     
}
